module.exports = {
    BTC: {
        BUY: false,
        SELL: false
    },
    LESS_WIN: false,
    BOT: true,
    PRICE_FUND_ON_OFF: true,
    //PRICE_FUND_DEFAULT: 0,
    // PRICE_FUND_NEXT: 0,
    PRICE_FUND_PROFITS: 0,
    //PRICE_FUND_RATE: 70
}